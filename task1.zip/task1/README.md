# Tech used
1. cypress
2. javascript
3. JSON

# Prepare Environment

1. navigate to project root in terminal
2. run the command - npm install


# Execute Tests with IDE

1. Run the command - npx cypress open
2. Once terminal is open click on file you wish to run
3. Watch the test execute

# Execute Tests headless

1. Run command - npx cypress run
2. See the console report displayed in terminal
3. See video artifact in video folder
4. See screenshots in screenshot folder


