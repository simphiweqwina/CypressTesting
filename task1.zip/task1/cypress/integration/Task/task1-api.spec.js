/// <reference types="Cypress" />
context('Task1-Intergration Test Suite',()=>{
    let _apiResponse;

    beforeEach(()=>{

        //get all breeds;
        cy.request('GET','https://dog.ceo/api/breeds/list/all').as('get_all_breeds');
        cy.get('@get_all_breeds').should(res=>{
            _apiResponse = res.body;
        });

        //get image retrival expected result
        cy.fixture('dog-Image-Api-Response-Data.json').as('ExpectedImage-Result')
  })

    it('should return a status 200/success',()=>{
       expect(_apiResponse.status).equal('success');
    });

    it('should should contain "retriever" in breed list',()=>{
        expect(_apiResponse.message,).to.have.property( "retriever");
    });

    it('should contain more than 0 sub-breeds of "retriever" ',()=>{
        const subBreadArray = _apiResponse.message.retriever;

        expect(subBreadArray).length.to.be.greaterThan(0);
    });

    it('should return random image list of retriever breed',()=>{
        cy.fixture('dog-Image-Api-Response-Data.json')
            .then((data)=>{

                cy.request('GET','https://dog.ceo/api/breed/'+data.breedImageSearchTearm+'/images/random')
                .then((res)=>{
                    expect(res.status).equal(data.status)
                    expect(res.body.message).to.contain('https:\/\/images.dog.ceo\/breeds')
                });

            });

    })

});