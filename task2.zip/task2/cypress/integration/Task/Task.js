
const { Given, When, Then,And } = require("cypress-cucumber-preprocessor/steps");

let fakeName ="";
Given('the user navigates to the way2automation website',()=>{
    cy.visit('https://way2automation.com/angularjs-protractor/webtables/');
})

And('the user table is visible',()=>{
    //locate the table by class
    cy.get('.smart-table').should('exist');
})

When('the user adds a person',(datatable)=>{

    //click the add user button

    datatable.hashes().forEach((element) => {
        cy.get('button[class="btn btn-link pull-right"]').click();

        //enter first name
        cy.get('input[name="FirstName"]')
        .clear()
        .type(element.FirstName);
        
        //enter last name
        cy.get('input[name="LastName"]')
        .clear()
        .type(element.LastName);

        //enter random username
        //let faker = require('faker');
        fakeName = getRandomString(5);
        cy.get('input[name="UserName"]')
        .clear()
        .type(fakeName);

        //enter Password
        cy.get('input[name="Password"]')
        .clear()
        .type(element.Password);

        //select company
        if(element.Company == 'Company AAA'){
            cy.get('input[type="radio"]').first().check()
        }
        if(element.Company == 'Company BBB'){
            cy.get('input[type="radio"]').eq(1).check()
        }
        //select role
        cy.get('select[name="RoleId"]').select(element.Role);

        //enter Email
        cy.get('input[name="Email"]')
        .clear()
        .type(element.Email);

        //enter Cell
        cy.get('input[name="Mobilephone"]')
        .clear()
        .type(element.Mobilephone);

        //click submit
        cy.get('button[class="btn btn-success"]').click();

        //validate modal closed
        cy.get('div[class="modal ng-scope"]').should('not.exist');

        //validate that username is unique
        cy.contains(fakeName).should('have.length', 1)

    });

    Then('the user should be added to the list',(datatable)=>{
        datatable.hashes().forEach((element) => {
            cy.contains(element.FirstName);
            cy.contains(element.LastName);
            cy.contains(element.Email);
            cy.contains(element.Mobilephone);
            cy.get('tr')
            .filter(':contains("'+element.FirstName+'")')
            .filter(':contains("'+element.LastName+'")')
            .filter(':contains("'+element.Email+'")')
            .filter(':contains("'+element.Mobilephone+'")')
            .filter(':contains("'+element.Company+'")')
            .should('have.length', 1)

    });
    })
})

function getRandomString(length) {
    var randomChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var result = '';
    for ( var i = 0; i < length; i++ ) {
        result += randomChars.charAt(Math.floor(Math.random() * randomChars.length));
    }
    return result;
}

